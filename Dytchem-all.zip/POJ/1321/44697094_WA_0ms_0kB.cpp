#include <iostream>
#include <utility>
#include <vector>
using namespace std;

int n, k;
vector<pair<int, int>> v;
int cnt;
bool row[9], col[9];

void dfs(const int i, const int t) {
	if (t == k) {
		++cnt;
		return;
	}
	for (int j = i + 1;j < v.size();++j) {
		if (row[v[j].first] || col[v[j].second]) continue;
		row[v[j].first] = col[v[j].second] = true;
		dfs(j, t + 1);
		row[v[j].first] = col[v[j].second] = false;
	}
}

int alldfs() {
	cnt = 0;
	for (int i = 0;i < v.size();++i) dfs(i, 1);
	return cnt;
}

int main() {
	while (true) {
		v.clear();
		cin >> n >> k;
		if (n == -1) break;
		for (int i = 1;i <= n;++i)
			for (int j = 1;j <= n;++j) {
				char c;
				cin >> c;
				if (c == '#') v.push_back(make_pair(i, j));
			}

		cout << alldfs() << '\n';
	}
}