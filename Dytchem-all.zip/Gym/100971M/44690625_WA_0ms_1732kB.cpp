#define _CRT_SECURE_NO_WARNINGS
#include <bits/stdc++.h>
using namespace std;
constexpr int Inf = 0x7fffffff;

char s[200005];
int w[200000] = { -1 };
int nxt[200000];

int main() {
	int k;
	scanf("%d", &k);
	getchar();

	int cnt = 0;
	map<int, bool> mp;
	int tmp = 0;
	char c = s[0];
	int i = 0;
	for (;(s[i] = getchar()) != EOF;++i) {
		if (s[i] == c) nxt[i] = tmp;
		else {
			tmp = nxt[i] = i;
			c = s[i];
		}

		mp[s[i]] = true;
		if (mp.size() == k + 1) {
			w[i - 1] = ++cnt;
			mp.clear();
			mp[s[i]] = true;
		}
	}

	const int len = i;

	mp.clear();
	i = 0;
	for (;i < len;++i) {
		if (w[i] > 0) break;
		mp[s[i]] = true;
		w[i] = mp.size() == k ? 1 : -1;
		cout << w[i] << ' ';
	}


	for (;i < len;++i) {
		if (w[i]) cout << w[i] << ' ';
		else {
			mp.clear();
			int j = i;
			w[i] = Inf;
			for (;j >= 0;--j) {
				if (nxt[j] != j) j = nxt[j] + 1;
				mp[s[j]] = true;
				if (mp.size() == k) {
					if (j == 0) {
						w[i] = 1;
						break;
					}
					if (w[j - 1] == -1) continue;
					w[i] = min(w[i], w[j - 1] + 1);
				}
				else if (mp.size() == k + 1) {
					break;
				}
			}
			if (w[i] == Inf) w[i] = -1;
			cout << w[i] << ' ';
		}
	}
}