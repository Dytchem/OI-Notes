#include <bits/stdc++.h>
using namespace std;
constexpr int Inf = 0x7fffffff;

int w[200000] = { -1 };

int main() {
	ios::sync_with_stdio(false);
	int k;
	string s;
	cin >> k >> s;

	int cnt = 0;
	map<int, bool> mp;
	for (int i = 0;i < s.size();++i) {
		mp[s[i]] = true;
		if (mp.size() == k + 1) {
			w[i - 1] = ++cnt;
			mp.clear();
			mp[s[i]] = true;
		}
	}

	mp.clear();
	int i = 0;
	for (;i < s.size();++i) {
		if (w[i] > 0) break;
		mp[s[i]] = true;
		w[i] = mp.size() == k ? 1 : -1;
		cout << w[i] << ' ';
	}


	for (;i < s.size();++i) {
		if (w[i]) cout << w[i] << ' ';
		else {
			mp.clear();
			int j = i;
			w[i] = Inf;
			for (;j >= 0;--j) {
				mp[s[j]] = true;
				if (mp.size() == k) {
					if (j == 0) {
						if (mp.size() == k) w[i] = 1;
						break;
					}
					if (w[j - 1] == -1) continue;
					w[i] = min(w[i], w[j - 1] + 1);
					break;
				}
				else if (mp.size() == k + 1) {
					break;
				}
			}
			if (w[i] == Inf) w[i] = -1;
			cout << w[i] << ' ';
		}
	}
}