#include <bits/stdc++.h>
using namespace std;

int n;
int a[100000];
map<pair<int, int>, int> mp;

int dfs(const pair<int, int>& pr) { // q, p
	if (pr.first + pr.second >= n) return a[pr.first];
	if (mp[pr] != 0) return mp[pr];
	int re = dfs(make_pair(pr.first, pr.second << 1)) + dfs(make_pair(pr.first + pr.second, pr.second << 1));
	mp[pr] = re;
	return re;
}

int main() {
	ios::sync_with_stdio(false);
	int Q;
	cin >> n >> Q;
	for (int i = 0;i < n;++i) cin >> a[i];
	while (Q--) {
		int p, q;
		cin >> q >> p;
		if (p == 0) {
			cout << 0 << '\n';
			continue;
		}
		cout << dfs(make_pair(q, p)) << '\n';
	}
}