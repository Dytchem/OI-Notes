#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
	ios::sync_with_stdio(false);cin.tie(nullptr);
	int n;
	cin >> n;
	map<string, int> mp;
	for (int i = 0;i < n;++i) {
		string s;
		cin >> s;
		mp[s]++;
	}
	int m;
	cin >> m;
	map<string, int> cor, wro;
	for (int i = 0;i < m;++i) {
		string d, e, c;
		cin >> d >> e >> c;
		if (c == "correct") cor[d]++;
		else wro[d]++;
	}
	ll cntc = 1, cnta = 1;
	for (auto& p : mp) {
		cntc *= pow(cor[p.first], p.second);
		cnta *= pow(cor[p.first] + wro[p.first], p.second);
	}
	ll cntw = cnta - cntc;
	if (cntc == 0) {
		cout << "the suckers are out working";
	}
	else if (cntc == 1) {
		cout << "correct";
	}
	else {
		cout << cntc << " correct";
	}
	cout << '\n';
	if (cntw == 0) {
		cout << "the suckers are out working";
	}
	else if (cntw == 1) {
		cout << "incorrect";
	}
	else {
		cout << cntw << " incorrect";
	}
}