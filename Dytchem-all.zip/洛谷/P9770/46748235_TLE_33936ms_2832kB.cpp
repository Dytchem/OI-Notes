#include <iostream>

using namespace std;
typedef long long ll;
// define int long long

int n, a[200005];
int ans[200005];

void deal(int pos, int val)
{
	if (a[pos] != 0 && a[pos] != val)
		deal(max(a[pos], val), min(a[pos], val));
	a[pos] = val;
}

signed main()
{
	ios::sync_with_stdio(false), cin.tie(nullptr), cout.tie(nullptr);
	cin >> n;
	for (int i = 1; i <= n; ++i)
	{
		cin >> a[i];
		if (a[i] == a[i - 1] + 1)
			continue;
		for (int j = a[i] - 1; j > 0; --j)
			deal(i - j, a[i] - j);
	}
	int o = 1;
	for (int i = 1; i <= n; ++i)
	{
		if (a[i] == 0)
			ans[i] = o++;
		else
			ans[i] = ans[a[i]];
		cout << ans[i] << ' ';
	}
}