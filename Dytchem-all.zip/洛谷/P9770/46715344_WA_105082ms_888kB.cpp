#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
constexpr int Inf = 0x3f3f3f3f;
// #define int long long

int n;
int ans[400005];

int main()
{
    cin >> n;
    for (int i = 1; i <= n; ++i) {
        int a;
        cin >> a;
        int d  = i - a;
        int ma = 0;
        for (int j = 1; j <= d; ++j) {
            if (ans[j] == 0)
                ans[j] = ma + 1, ++ma;
            else
                ma = max(ma, ans[j]);
        }
        for (int j = 1; j <= a; ++j) {
            ans[j + d] = ans[j];
        }
    }
    int ma = 0;
    for (int j = 1; j <= n; ++j) {
        if (ans[j] == 0)
            ans[j] = ma + 1, ++ma;
        else
            ma = max(ma, ans[j]);
    }
    for (int i = 1; i <= n; ++i)
        cout << ans[i] << ' ';
}