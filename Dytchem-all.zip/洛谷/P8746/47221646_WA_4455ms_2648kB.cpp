#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef __int128 lll;
//#define int long long
#define Inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f

const int N = 102, M = 51;
int n,m,a[N],sum[N];
int stf[N][N][M];

inline int S(int l,int r){
	return sum[r]-sum[l-1];
} 

int mi;
int f(int end1=0,int end2=0,int now=1){
	if (end1>end2) swap(end1,end2);
	if (stf[end1][end2][now]!=Inf) return stf[end1][end2][now];
	if (now==m){
		for (int i=min(n,end2+1);i>=end1+1;--i){
			int s=S(i,n);
			if (s<mi) continue;
			return stf[end1][end2][now]=s;
		}
		return stf[end1][end2][now]=Inf-1;
	}
	
	int re=Inf-1,maxi=min(n,end2+1);
	for (int i=end1+1;i<=maxi;++i){
		int tmp=Inf-1;
		for (int j=i;j<=n;++j){
			int s=S(i,j);
			if (s<mi) continue;
			tmp=min(tmp,max(s,f(j,end2,now+1)));
			re=min(re,tmp);
		}
		stf[i-1][end2][now]=tmp;
	}
	
	return stf[end1][end2][now]=re;
}

signed main(){
	cin>>n>>m;
	for (int i=1;i<=n;++i) cin>>a[i],sum[i]=sum[i-1]+a[i];
	int maxmi=2*sum[n]/m+1,ans=Inf;
	for (mi=1;mi<=maxmi;++mi){
		memset(stf,0x3f,sizeof(stf));
		int ma=f();
		ans=min(ans,ma-mi);
	}
	cout<<ans;
	return 0;
}

/*

10 5
1 2 2 1 1 2 2 1 1 2

*/