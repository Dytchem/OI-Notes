#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef __int128 lll;
//#define int long long
#define Inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f

const int N = 102, M = 51;
int n,m,a[N];

int mi=101,ma=0,ansm=Inf;
void dfs(int end1=0,int end2=0,int now=1){
	if (ma-mi>=ansm) return;
	if (end1>end2) swap(end1,end2);
	if (now==m+1){
		if (end2==n) ansm=min(ansm,ma-mi);
		return;
	}
	for (int i=end1+1;i<=min(n,end2+1);++i){
		int sum=0;
		for (int j=i;j<=n;++j){
			sum+=a[j];
			int mi_t=mi,ma_t=ma;
			mi=min(mi,sum),ma=max(ma,sum);
			dfs(j,end2,now+1);
			mi=mi_t,ma=ma_t;
		}
	}
}

signed main(){
	cin>>n>>m;
	for (int i=1;i<=n;++i) cin>>a[i];
	dfs();
	cout<<ansm;
	return 0;
}

/*

10 5
1 2 2 1 1 2 2 1 1 2

*/