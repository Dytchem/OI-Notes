#include <iostream>
#include <utility>
#include <map>
using namespace std;
typedef long long ll;
//#define int long long
#define Inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f

const int N = 1003;
int n;
double A[N], B[N];
map<pair<float, float>, bool> mp;

signed main()
{
    cin >> n;
    int ans = 1;
    for (int i = 1; i <= n; ++i)
    {
        ++ans;
        cin >> A[i] >> B[i];
        map<pair<float, float>, bool> tmp;
        for (int j = 1; j < i; ++j)
        {
            if (A[j] == A[i])
                continue;
            float x = (B[i] - B[j]) / (A[j] - A[i]);
            float y = A[i] * x + B[i];
            pair<float, float> p(x, y);
            if (!mp[p])
            {
                ++ans;
                mp[p] = true;
            }
            else if (!tmp[p])
            {
                ++ans;
                tmp[p] = true;
            }
        }
    }
    cout << ans;
    return 0;
}