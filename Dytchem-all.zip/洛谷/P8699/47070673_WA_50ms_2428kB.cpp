#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
//#define int long long
#define Inf 0x3f3f3f3f

const int N=502,K=502,P=123456;

int stf[N][K][2];

int f(int n,int k,bool t){
	if (k<0) return 0;
	if (stf[n][k][t]!=Inf) return stf[n][k][t];
	int re;
	if ((k&1)==0)
		re=f(n-1,k-1,!t)+f(n-1,k,t)*k+f(n-1,k-2,t)*(n-k)%P;
	else if (t)
		re=f(n-1,k-1,t)+f(n-1,k-1,!t)+f(n-1,k,t)*(k-1)+f(n-1,k-2,t)*(n-k+1)%P;
	else
		re=f(n-1,k,t)*(k+1)+f(n-1,k-2,t)*(n-k-1)%P;
	
	return stf[n][k][t]=re%P;
}


signed main(){
	memset(stf,0x3f,sizeof(stf));
	for (int n=1;n<N;++n) stf[n][0][0]=stf[n][0][1]=1;
	for (int k=1;k<K;++k) stf[2][k][0]=stf[2][k][1]=0;
	stf[3][1][0]=stf[3][1][1]=2;
	
	int n,k;
	cin>>n>>k;
	
	cout<<f(n,k,0)+f(n,k,1);
	
	return 0;
}