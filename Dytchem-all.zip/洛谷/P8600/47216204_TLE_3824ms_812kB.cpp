#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef __int128 lll;
//#define int long long
#define Inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f

const int N = 50004;
int n,a[N];

signed main(){
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>n;
	for (int i=1;i<=n;++i) cin>>a[i];
	int ans=n;
	for (int i=1;i<=n;++i){
		int mi=a[i],ma=a[i];
		for (int j=i+1;j<=n;++j){
			mi=min(mi,a[j]);
			ma=max(ma,a[j]);
			if (ma-mi==j-i) ++ans;
		}
	}
	cout<<ans;
	
	return 0;
}