#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
//#define int long long
#define Inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f

const int S = 20000007;
const ll P = 1e9+7;

ll tail[S]{0,1,3};

signed main(){
	ll n;
	cin>>n;
	if (n==1) return cout<<1,0;
	else if (n==2||n==3) return cout<<2,0;
	ll Gx=3,Gy=2,ma=2;
	while (ma<n){
		if (Gx<=tail[Gy]) ma=tail[Gx]=ma+Gy,++Gx;
		else ++Gy;
	}
	cout<<(Gx-1)%P;
	
	return 0;
}