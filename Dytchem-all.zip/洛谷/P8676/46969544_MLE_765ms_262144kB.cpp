#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
//#define int long long
#define Inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f

const ll P = 1e9+7;

struct Node{
	ll tail;
	Node* nxt;
};

signed main(){
	ll n;
	cin>>n;
	if (n==1) return cout<<1,0;
	else if (n==2||n==3) return cout<<2,0;
	Node* now=new Node{3,NULL};
	Node* lst=now;
	ll Gx=3,Gy=2,ma=3;
	while (ma<n){
		if (Gx<=now->tail){
			lst=lst->nxt=new Node{ma+=Gy,NULL};
			++Gx;
		}
		else{
			Node* tmp=now;
			now=now->nxt;
			delete tmp;
			++Gy;
		}
	}
	cout<<(Gx-1)%P;
	
	return 0;
}

/*

2000000000000000

*/