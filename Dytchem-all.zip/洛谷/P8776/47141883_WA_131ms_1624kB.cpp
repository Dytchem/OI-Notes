#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef __int128 lll;
//#define int long long
#define Inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f

const int N = 100005;
int n,k;
int a[N];
int dp[2][N];

signed main(){
	cin>>n>>k;
	for (int i=1;i<=n;++i) cin>>a[i];
	
	for (int i=1;i<=n+1;++i){
		if (a[i-1]>a[i]){
			dp[0][i]=1;
			int j=i-1;
			for (int y=1;y<dp[0][j];++y){
				int z=j-y-k;
				if (z>=0&&a[z]<=a[j-y+1]) dp[1][j]=max(dp[1][j],y+k+dp[0][z]);
			}
		}
		else dp[0][i]=dp[0][i-1]+1;
		int y=dp[0][i],z=i-y-k;
		dp[1][i]=min(y+k,i);
		if (z>=0&&a[z]<=a[i-y+1]) dp[1][i]=max(dp[1][i],y+k+dp[0][z]);
	}
	
	cout<<*max_element(&dp[1][1],&dp[1][n]+1);
	
	return 0;
}



/*

10 5
1 2 3 4 5 4 3 2 1 9

10 3
1 2 3 1 2 3 1 2 3 1

10 1
9 8 7 6 5 4 3 2 1 1

30 5
1 2 3 4 8 4 9 7 1 5
5 4 7 8 1 10 2 5 85 4
1 5 45 8 4 78 65 2 1 4


*/