#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef __int128 lll;
//#define int long long
#define Inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f

const int N = 100005;
int n,k;
int a[N];
int L[N],R[N];
int tmp[N],len;

signed main(){
	cin>>n>>k;
	for (int i=1;i<=n;++i) cin>>a[i];
	
	tmp[0]=a[1]; len=1;
	L[1]=1;
	for (int i=2;i<=n;++i){
		int t=upper_bound(tmp,tmp+len,a[i])-tmp;
		if (t==len) tmp[len++]=a[i];
		else tmp[t]=a[i];
		L[i]=t+1;
	}
	//for (int i=1;i<=n;++i) cout<<L[i]<<' ';
	
	tmp[0]=a[n]; len=1;
	R[n]=1;
	for (int i=n-1;i>=1;--i){
		int t=upper_bound(tmp,tmp+len,a[i],greater<int>())-tmp;
		if (t==len) tmp[len++]=a[i];
		else tmp[t]=a[i];
		R[i]=t+1;
	}
	//for (int i=1;i<=n;++i) cout<<R[i]<<' ';
	
	int ans=k+1;
	for (int i=k+2;i<=n;++i){
		ans=max(ans,(a[i-k-1]<=a[i])*L[i-k-1]+k+R[i]);
	}
	
	cout<<ans;
	
	return 0; 
} 

/*

10 1
1 4 2 8 5 6 8 9 0 1

*/