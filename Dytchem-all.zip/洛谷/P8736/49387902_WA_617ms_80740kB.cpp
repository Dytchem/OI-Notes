#include <bits/stdc++.h>
using namespace std;
//#define int ll
typedef long long ll;
#define INF 0x3f3f3f3f3f3f3f3f
#define Inf 0x3f3f3f3f

const int N = 1000006;
char a0[N];
string a[N];
pair<string,int> ps[N];
int n=0;
int b[N],ans[N],ans1[N],pre[N];

signed main(){
	cin>>a0;
	int l=strlen(a0);
	for (int i=0;i<l;){
		a[++n].push_back(a0[i]);
		for (++i;'a'<=a0[i]&&a0[i]<='z';++i) a[n].push_back(a0[i]);
	}
	//for (int i=1;i<=n;++i) cout<<a[i]<<'\n';
	for (int i=1;i<=n;++i) ps[i]=make_pair(a[i],i);
	sort(ps+1,ps+1+n);
	for (int i=1;i<=n;++i){
		b[ps[i].second]=i;
	}
	//for (int i=1;i<=n;++i) cout<<b[i]<<' '; cout<<'\n';
	int lenn=0;
	for (int i=1;i<=n;++i){
		int pos=upper_bound(ans,ans+1+lenn,b[i])-ans;
		pre[i]=ans1[pos-1];
		if (pos==lenn+1){
			ans[++lenn]=b[i];
			ans1[lenn]=i;
		}
		else{
			ans[pos]=b[i];
			ans1[pos]=i;
		}
		//for (int j=0;j<=len;++j) cout<<ans[j]<<' '; cout<<'\n'; 
	}
	//cout<<lenn;
	for (int i=ans1[lenn],j=n+1;i;i=pre[i]) ans[--j]=ans1[i];
	for (int i=1;i<=lenn;++i) cout<<a[ans1[i]];
}

/*

ABCEDYXZ
*/