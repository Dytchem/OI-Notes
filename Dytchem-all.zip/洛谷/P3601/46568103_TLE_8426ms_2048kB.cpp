#include <cstdio>
#include <vector>
using namespace std;
typedef long long ll;

template <typename T>
inline void read(T &a)
{
	a = 0;
	char c = getchar();
	while (c < '0' || c > '9')
	{
		c = getchar();
	}
	while (c >= '0' && c <= '9')
	{
		a = (a << 1) + (a << 3) + (c ^ 48);
		c = getchar();
	}
}

const int maxsize = 1000006;
const ll MOD = 666623333;
bool vis[maxsize];
vector<int> ps;

inline void init()
{
	for (int i = 2; i <= maxsize; ++i)
	{
		if (!vis[i])
			ps.push_back(i);
		for (int j : ps)
		{
			if (i * j > maxsize)
				break;
			vis[i * j] = true;
			if (i % j == 0)
				break;
		}
	}
	// for (int i:ps) printf("%d ",i);
}

int main()
{
	init();
	ll l, r;
	read(l), read(r);
	ll ans = (l + r) * (r - l + 1) / 2 % MOD;
	for (ll x = l; x <= r; ++x)
	{
		// printf("%lld\n", x);
		ll re = x, m = 1, y = x;
		for (int i : ps)
		{
			if (i > y)
				break;
			if (y % i == 0)
			{
				re /= i;
				m = m * (i - 1);
				do
				{
					y /= i;
				} while (y % i == 0);
			}
		}
		if (y == 1)
			re *= m;
		else
			re = re / y * (y - 1) * m;
		ans -= re;
	}
	printf("%lld", (ans % MOD + MOD) % MOD);
}