#include <bits/stdc++.h>
using namespace std;
//#define int ll
typedef long long ll;
#define INF 0x3f3f3f3f3f3f3f3f
#define Inf 0x3f3f3f3f

const int N = 10004, M = 100005;
int n,m;

struct Road{
	int hed[N],to[M<<1],nxt[M<<1],wgt[M<<1],pos=0;
	void add_one(int u,int v,int w){
		for (int i=hed[u];i;i=nxt[i]){
			if (to[i]==v){
				if (w<wgt[i]){
					wgt[i]=w;
				}
				return;
			}
		}
		nxt[++pos]=hed[u];
		hed[u]=pos;
		to[pos]=v;
		wgt[pos]=w;
	}
	void add(int u,int v,int w){
		add_one(u,v,w);
		add_one(v,u,w);
	}
	int min12n(){
		//int d[N]; d[N]=0;
		bool vis[N]; memset(vis,0,sizeof(vis));
		priority_queue<pair<int,int>,vector<pair<int,int> >,greater<pair<int,int> > > q;
		q.push(make_pair(1,0));
		while (!q.empty()){
			int u=q.top().first,d=q.top().second;
			if (u==n) return d;
			q.pop();
			if (vis[u]) continue; 
			vis[u]=true;
			for (int i=hed[u];i;i=nxt[i]){
				if (vis[to[i]]) continue;
				q.push(make_pair(to[i],d+wgt[i]));
			}
		}
	}
}road;

struct Tmp{
	int u,v,w;
};
vector<Tmp> tmps;

signed main(){
	cin>>n>>m;
	while(m--){
		int u,v,w,c;cin>>u>>v>>w>>c;
		if (c){
			tmps.push_back(Tmp{u,v,w});
		}
		else{
			road.add(u,v,w);
		}
	}
	int a=road.min12n();
	for (int i=0;i<tmps.size();++i){
		road.add(tmps[i].u,tmps[i].v,tmps[i].w);
	}
	cout<<a-road.min12n();
	return 0;
}

/*

5 7
1 2 1 0
2 3 2 1
1 3 9 0
5 3 8 0
1 5 1 1
4 3 9 0
4 5 4 0

*/