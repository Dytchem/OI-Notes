#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
constexpr int Inf = 0x3f3f3f3f;
#define int long long

// 答案 = (nk-1)!/[(nk-n)!(n-1)!(k-1)^(n-1)] = C(nk-1,n-1)/(k-1)^(n-1);

const int MOD = 1145141;
int fac[MOD]{1, 1}, inv[MOD]{1, 1};

inline int qpow(int a, int n)
{
    int re = 1;
    while (n) {
        if (n & 1)
            re = re * a % MOD;
        a = a * a % MOD;
        n >>= 1;
    }
    return re;
}

inline void init()
{
    for (int i = 2; i < MOD; ++i) {
        fac[i] = fac[i - 1] * i % MOD;
        inv[i] = qpow(fac[i], MOD - 2);
    }
}

inline int C(int n, int m)
{
    int a = n / MOD, b = m / MOD, c = (n - m) / MOD;
    if (a == b + c) {
        return fac[n % MOD] * inv[m % MOD] % MOD * inv[(n - m) % MOD] % MOD;
    }
    else
        return 0;
}

inline int solve(int n, int k)
{
    int c = C(n * k - 1, n - 1);
    if (c == -1)
        return -1;
    else
        return c * qpow(qpow(k - 1, (n - 1) % (MOD - 1)), MOD - 2) % MOD;
}

signed main()
{
    init();
    ios::sync_with_stdio(false), cin.tie(nullptr), cout.tie(nullptr);
    int t;
    cin >> t;
    while (t--) {
        int n, k;
        cin >> n >> k;
        cout << solve(n, k) << '\n';
    }
}