#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
//#define int long long
#define Inf 0x3f3f3f3f

struct ticket{
	int day,wgt;
	bool operator < (const ticket& t) {
		return day<t.day;
	}
};

const int N = 1003, M = 5003;
int days[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
int n,m,k;
ticket a[N];
int stf[N][M];

int f(int num,int mny){
	if (mny<=0||a[num].wgt>mny) return 0;
	if (stf[num][mny]!=Inf) return stf[num][mny];
	int re=a[num].wgt;
	for (int i=num-1;i>=1;--i){
		if (a[num].day-a[i].day<k) continue;
		int tmp=a[num].wgt+f(i,mny-a[num].wgt);
		if (tmp>mny) continue;
		else if (tmp==mny) {
			re=mny;
			break;
		}
		re=max(re,tmp);
	}
	return stf[num][mny]=re;
}

signed main(){
	for (int i=1;i<=12;++i) days[i]+=days[i-1];
	//cout<<days[12];
	memset(stf,0x3f,sizeof(stf));
	cin>>n>>m>>k;
	for (int i=1;i<=n;++i){
		int m,d;
		cin>>m>>d>>a[i].wgt;
		a[i].day=days[m-1]+d;
	}
	sort(a+1,a+1+n);
	int ans=-1;
	for (int i=n;i>=1;--i){
		ans=max(ans,f(i,m));
		if (ans==m) return cout<<m,0;
	}
	return cout<<ans,0;
}