#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <numeric>
#include <cstring>
#include <cstdint>
#include <memory>

// D(X)=E(X²)-E(X)²
// n²D(X)=nS(X²)-S(X)²
// n²ΔDᵢ=(n-1)Xᵢ²-2Sᵢ₋₁Xᵢ
// Xᵢ=s[1+i..n+i]=(s[i]..n+i-1]<<1)-(s[i]<<n)+s[n+i]

using namespace std;
typedef long long ll;
typedef __int128 lll;
constexpr int Inf = 0x3f3f3f3f;
constexpr ll INF = 0x3f3f3f3f3f3f3f3f;

const int N = 60;
char s[N << 1], sm[N];
int n;

lll mi;
void dfs(int i, lll D, lll S, lll X)
{
	if (i == n + 1)
	{
		if (D < mi)
		{
			mi = D;
			memcpy(sm, s + n + 1, n);
		}
	}
	for (char j = 0; j <= 1; ++j)
	{
		lll X1 = X * 2 - ((ll)(s[i] - '0') << n) + j;
		lll D1 = D + (n - 1) * X1 * X1 - 2 * S * X1;
		lll S1 = S + X1;
		s[n + i] = j + '0';
		dfs(i + 1, D1, S1, X1);
	}
}

signed main()
{
	scanf("%s", s + 1);
	n = strlen(s + 1);

	mi = INF;
	mi = mi * INF;
	lll X = 0;
	for (int i = 1; i <= n; ++i)
	{
		X = X * 2 + s[i] - '0';
	}
	dfs(1, (n - 1) * X * X, X, X);

	printf("%s", sm);

	return 0;
}