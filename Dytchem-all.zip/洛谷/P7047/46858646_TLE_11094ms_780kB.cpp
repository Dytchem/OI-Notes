#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <numeric>
#include <cstring>
#include <cstdint>
#include <memory>
#include <vector>

// D(X)=E(X²)-E(X)²
// n²D(X)=nS(X²)-S(X)²
// n²ΔDᵢ=(n-1)Xᵢ²-2Sᵢ₋₁Xᵢ
// Xᵢ=s[1+i..n+i]=(s[i..n+i-1]<<1)-(s[i]<<n)+s[n+i]
// 题中统计数字为n+1个

using namespace std;
typedef long long ll;
typedef __int128 lll;
constexpr int Inf = 0x3f3f3f3f;
constexpr ll INF = 0x3f3f3f3f3f3f3f3f;

const int N = 60;
char s[N];
vector<char> tmp(N);
vector<vector<char>> ans;
int n;
lll maxX;

lll mi;
void dfs(int i, lll D, lll S, lll X)
{
	if (D - ((n - i + 1) * S * S + (n - i) * (n - i + 1) * maxX * S + (n - i) * (n - i + 1) * (2 * n - 2 * i + 1) * maxX * maxX / 6) / n > mi)
		return;
	if (i == n + 1)
	{
		// printf("%s %lld\n", s + n + 1, (ll)D);
		if (D <= mi)
		{
			if (D < mi)
			{
				ans.clear();
				mi = D;
			}
			ans.push_back(tmp);
		}
		return;
	}
	for (char j = 0; j <= 1; ++j)
	{
		lll X1 = (X << 1) - ((ll)(s[i] - '0') << n) + j;
		lll D1 = D + n * X1 * X1 - 2 * S * X1;
		lll S1 = S + X1;
		tmp[i] = j + '0';
		dfs(i + 1, D1, S1, X1);
	}
}

signed main()
{
	scanf("%s", s + 1);
	n = strlen(s + 1);

	mi = INF;
	mi = mi * INF;
	maxX = (1 << n) - 1;
	lll X = 0;
	for (int i = 1; i <= n; ++i)
	{
		X = (X << 1) + s[i] - '0';
	}
	dfs(1, n * X * X, X, X);

	for (auto &v : ans)
	{
		for (int i = 1; i <= n; ++i)
		{
			putchar(v[i]);
		}
		putchar('\n');
	}

	return 0;
}