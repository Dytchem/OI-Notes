#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

// f(1)=k, f(x)f(y)=f(x+y)+f(x-y) => f(t)=f(x)f(t-x)-f(2x-t) 应使 t=ceil(t/2)

int m, k, n;
const int M = 50000007;
int stf[M];

ll f(ll t)
{
    if (t < M && stf[t])
        return stf[t];
    int re;
    if (t & 1)
        re = stf[t] = (f(t >> 1) * f((t >> 1) + 1) - k) % m;
    else
        re = stf[t] = (f(t >> 1) * f(t >> 1) - 2) % m;
    if (t < M)
        stf[t] = re;
    return re;
}

int main()
{
    ios::sync_with_stdio(false), cin.tie(nullptr), cout.tie(nullptr);

    cin >> m >> k >> n;

    stf[0] = 2, stf[1] = k;
    cout << f(n);
}