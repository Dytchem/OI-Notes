#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>

using namespace std;
constexpr int Inf = 0x3f3f3f3f;

template <typename T>
inline void read(T &a)
{
	a = 0;
	char c = getchar();
	while (c < '0' || c > '9')
	{
		c = getchar();
	}
	while (c >= '0' && c <= '9')
	{
		a = (a << 1) + (a << 3) + (c ^ 48);
		c = getchar();
	}
}

int a, b;
int p[11];
int stf[10][10];

int f(int res, int now, bool flag) // flag代表前面数位是否饱和
{
	if (now == -1)
		return 1;
	int re = 0;
	if (flag)
	{
		if (res == -2)
		{ // res = -2代表前导0
			if (p[now] == 0)
				re += f(-2, now - 1, true);
			else
				re += f(-2, now - 1, false);
			for (int i = 1; i <= p[now]; ++i)
				re += f(i, now - 1, i == p[now]);
			return re;
		}
		else
		{
			for (int i = 0; i <= p[now]; ++i)
			{
				if (abs(i - res) < 2)
					continue;
				re += f(i, now - 1, i == p[now]);
			}
			return re;
		}
	}
	else
	{
		if (res == -2)
		{
			re += f(-2, now - 1, false);
			for (int i = 1; i <= 9; ++i)
				re += f(i, now - 1, false);
			return re;
		}
		else
		{
			return stf[res][now];
		}
	}
}

int work(int a)
{
	for (int i = 0; i <= 10; ++i)
	{
		p[i] = a % 10;
		a /= 10;
	}
	return f(-2, 9, true);
}

signed main()
{
	for (int res = 0; res < 10; ++res)
	{
		for (int i = res - 2; i >= 0; --i)
			stf[res][0] += 1;
		for (int i = res + 2; i <= 9; ++i)
			stf[res][0] += 1;
		for (int now = 1; now < 10; ++now)
		{
			for (int i = res - 2; i >= 0; --i)
				stf[res][now] += stf[i][now - 1];
			for (int i = res + 2; i <= 9; ++i)
				stf[res][now] += stf[i][now - 1];
		}
	}
	read(a), read(b);
	printf("%d", work(b) - work(a - 1));
}