#include <bits/stdc++.h>
using namespace std;

const int N = 100005;
int n,m;
int a[N];
int tmp[N];

signed main(){
	cin>>n>>m;
	for (int i=1;i<=n;++i){
		a[i]=i;
	}
	int mid=1; // 下降与上升的分界点（上升的起点） 
	while (m--){
		int p,q;cin>>p>>q;
		if (p==0){
			if (q>mid-1){
				int x=mid-1,y=mid,z=q;
				while (x>=1&&y<=q){
					if (a[x]<a[y]) tmp[z--]=a[x--];
					else tmp[z--]=a[y++];
				}
				while (x>=1) tmp[z--]=a[x--];
				while (y<=q) tmp[z--]=a[y++];
				for (int i=1;i<=q;++i) a[i]=tmp[i];
				mid=q+1;
			}
		}
		else{
			if (q<mid){
				int x=mid-1,y=mid,z=q;
				while (x>=q&&y<=n){
					if (a[x]<a[y]) tmp[z++]=a[x--];
					else tmp[z++]=a[y++];
				}
				while (x>=q) tmp[z++]=a[x--];
				while (y<=n) tmp[z++]=a[y++];
				for (int i=q;i<=n;++i) a[i]=tmp[i];
				mid=q;
			}
		}
	}
	for (int i=1;i<=n;++i){
		cout<<a[i]<<' ';
	}
	
	return 0;
}