#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
//#define int long long
#define Inf 0x3f3f3f3f

const int N = 100005;

int n,k;
int p[N],m[N];
ll cnt[11][N];

int solve_p(int x){
	int re=0;
	while (x){
		re++;
		x/=10;
	}
	return re;
}

signed main(){
	cin>>n>>k;
	for (int i=1;i<=n;++i){
		int a;
		cin>>a;
		p[i]=solve_p(a);
		m[i]=a%=k;
		for (int i=1;i<=n;++i){
			a=(a*10)%k;
			cnt[i][a]++;
		}
	}
	ll ans=0;
	for (int i=1;i<=n;++i){
		ans+=cnt[p[i]][(k-m[i])%k]-(m[i]==0);
	}
	
	cout<<ans;
	
	return 0;
}