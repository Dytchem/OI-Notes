#include <iostream>
#include <queue>

using namespace std;
typedef long long ll;
constexpr int Inf = 0x3f3f3f3f;
#define int long long

int y, n, m;
int a[10];
int dis[5000006];

inline void bfs()
{
	queue<int> q;
	q.push(0);
	int tm = 0;
	while (!q.empty())
	{
		int t = q.front();
		q.pop();
		for (int i = min(n, y - t); i >= 0; --i)
		{
			int o = t + i;
			if (o == tm)
				break;
			if (dis[o])
				continue;
			dis[o] = dis[t] + 1;
			if (o == y)
				return;
			q.push(o);
		}
		for (int i = 0; i < m; ++i)
		{
			int o = t * a[i];
			if (o <= 0 || o > y)
				break;
			if (dis[o])
				continue;
			dis[o] = dis[t] + 1;
			if (o == y)
				return;
			q.push(o);
		}
		tm = t + n;
	}
}

signed main()
{
	ios::sync_with_stdio(false), cin.tie(nullptr), cout.tie(nullptr);

	cin >> y >> n >> m;
	for (int i = 0; i < m; ++i)
		cin >> a[i];
	sort(a, a + m);
	bfs();
	cout << dis[y];
}