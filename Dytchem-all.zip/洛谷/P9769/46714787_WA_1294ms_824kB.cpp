#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
constexpr int Inf = 0x3f3f3f3f;
// #define int long long

int main()
{
    ios::sync_with_stdio(false), cin.tie(nullptr), cout.tie(nullptr);
    int y, n, m;
    cin >> y >> n >> m;
    vector<int> v;
    for (int i = 0; i < m; ++i) {
        int a;
        cin >> a;
        v.push_back(a);
    }
    sort(v.begin(), v.end());
    int ans = 0;
    for (int i = m - 1; i >= 0; --i) {
        if (y <= n)
            break;
        if (y % v[i])
            continue;
        else {
            do {
                y /= v[i];
                ++ans;
            } while (y % v[i] == 0);
        }
    }
    cout << ans + 1;
}