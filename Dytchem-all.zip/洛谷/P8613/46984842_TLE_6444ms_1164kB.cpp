#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
//#define int long long
#define Inf 0x3f3f3f3f

const int N = 100005;

int n;

struct One{
	int t,h;
}a[100005];

signed main(){
	cin>>n;
	for (int i=1;i<=n;++i) cin>>a[i].h;
	a[0].h=Inf;
	for (int i=1;i<n;++i){
		int jm=0;
		for (int j=i;j<=n;++j){
			if (a[jm].h>a[j].h) jm=j;
		}
		for (int j=jm-1;j>=i;--j){
			swap(a[j],a[j+1]);
			++a[j].t,++a[j+1].t;
		}
	}
	ll ans=0;
	for (int i=1;i<=n;++i){
		ans+=a[i].t*(a[i].t+1)/2;
	}
	cout<<ans;
}