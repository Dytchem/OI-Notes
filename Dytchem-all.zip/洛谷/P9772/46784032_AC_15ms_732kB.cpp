#include <iostream>

using namespace std;
typedef long long ll;

int main()
{
	cout << "Kelin";
}