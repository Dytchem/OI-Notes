#include <iostream>
using namespace std;

const int N = 100005;

int a[N];
bool vis[N];

int main()
{
    int n;
    cin >> n;
    for (int i = 1; i <= n; ++i) cin >> a[i];
    long long ans = 1;
    for (int i = 1; i <= n; ++i) {
        if (vis[i]) continue;
        vis[i] = true;
        int j = a[i];
        int d = 1;
        while (!vis[j]) {
            vis[j] = true;
            ++d;
            j = a[j];
        }
        long long ans1 = 0;
        for (long long x = 0; x < d; ++x) {
            if ((x * n - 1) % d == 0) ++ans1;
        }
        ans = ans * ans1 % 998244353;
    }
    cout << ans;
}

