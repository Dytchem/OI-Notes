#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
constexpr int     Inf = 0x3f3f3f3f;
constexpr ll      INF = 0x3f3f3f3f3f3f3f3f;

const ll  MOD = 998244353;
const int N   = 100005;
int       nxt[N], cnt[N];
bool      vis[N];
ll        fac[N], inv[N];

ll qpow(int a, int n)
{
    if (n == 0)
        return 1;
    ll t = qpow(a, n / 2);
    t    = t * t % MOD;
    return t * (n & 1 ? a : 1) % MOD;
}

bool isp(int a, int b)
{
    if (b == 0)
        return a == 1;
    else
        return isp(b, a % b);
}

ll g(int a)
{
    ll re = 1;
    for (int i = 2; i < a; ++i) {
        if (isp(a, i))
            ++re;
    }
    return re;
}

ll C(int n, int m)
{
    return (fac[n] * inv[m] % MOD) * inv[n - m] % MOD;
}

ll f(int size, int n)
{
    ll re = 0;
    if (n == 0)
        return 1;
    for (int i = 1; i <= n; ++i) {
        re = (re + (((C(n - 1, n - i) * qpow(size, i - 1) % MOD) * fac[i - 1] % MOD) * g(size) % MOD) * f(size, n - i)) % MOD;
    }
    return re;
}

int main()
{
    fac[0] = inv[0] = 1;
    for (int i = 1; i < N; ++i) {
        fac[i] = fac[i - 1] * i % MOD;
        inv[i] = qpow(fac[i], MOD - 2);
    }

    int n;
    cin >> n;
    for (int i = 1; i <= n; ++i)
        cin >> nxt[i];
    for (int i = 1; i <= n; ++i) {
        if (vis[i])
            continue;
        vis[i] = true;
        int j = nxt[i], c = 1;
        while (!vis[j]) {
            ++c;
            vis[j] = true;
            j      = nxt[j];
        }
        ++cnt[c];
    }
    ll ans = 1;
    for (int i = 1; i <= N; ++i) {
        if (!cnt[i])
            continue;
        ans = ans * f(i, cnt[i]) % MOD;
    }
    cout << ans;

    return 0;
}