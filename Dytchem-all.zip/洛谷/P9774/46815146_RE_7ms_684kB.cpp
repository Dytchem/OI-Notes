#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

#define int ll

int stans[2000006];

signed main()
{
    ios::sync_with_stdio(false), cin.tie(nullptr), cout.tie(nullptr);
    int T, p;
    cin >> T >> p;
    stans[0] = stans[1] = 1;
    for (int i = 2; i < p; ++i)
        stans[i] = stans[i - 1] * i % p;
    while (T--) {
        int n;
        cin >> n;
        int k = n / p, x = n - k * p;
        int ans;
        ans = ((k & 1 ? -stans[k] : stans[k]) * stans[x] % p + p) % p;
        cout << ans << '\n';
    }
}