#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

template <typename T>
inline void read(T &a)
{
	a = 0;
	char c = getchar();
	while (c < '0' || c > '9')
	{
		c = getchar();
	}
	while (c >= '0' && c <= '9')
	{
		a = (a << 1) + (a << 3) + (c ^ 48);
		c = getchar();
	}
}

constexpr int N = 1000006,
			  M = 3000006, S = 2 * (M + N), Inf = 0x3f3f3f3f;

int n, m0, m;
int hed[N], hed1[N], siz[N], nxt[S], to[S];
char wgt[S >> 1];
bool vis[S >> 1];
char ans[M];
int p = -1;

inline void add(int u, int v, char w)
{
	to[++p] = v;
	wgt[p >> 1] = w;
	nxt[p] = hed[u];
	hed[u] = p;
	++siz[u];
}

void dfs(int t, char w)
{
	// 从to开始走，不能再走vis[p/2]的边
	if (w == 2)
		swap(hed[t], hed1[t]);
	for (int i = hed[t]; i != Inf; i = nxt[i])
	{
		if (vis[i >> 1] || wgt[i >> 1] != w)
			continue;
		if ((i >> 1) < m)
			ans[i >> 1] = i & 1;
		vis[i >> 1] = true;
		hed[t] = nxt[i];
		dfs(to[i], w);
	}
	for (int i = hed1[t]; i != Inf; i = nxt[i])
	{
		if (vis[i >> 1])
			continue;
		if ((i >> 1) < m)
			ans[i >> 1] = i & 1;
		vis[i >> 1] = true;
		hed1[t] = nxt[i];
		dfs(to[i], 3 - w);
	}
}

int main()
{
	memset(hed, 0x3f, sizeof(hed));
	memset(nxt, 0x3f, sizeof(nxt));

	read(n), read(m0);
	for (int i = 0; i < m0; ++i)
	{
		int u, v;
		char w;
		read(u), read(v), read(w);
		add(u, v, w), add(v, u, w);
	}
	m = m0;
	for (int i = 1; i <= n; ++i)
	{
		if (siz[i] & 1)
			add(0, i, 1), add(i, 0, 1), ++m;
	}
	memcpy(hed1, hed, sizeof(hed1));

	dfs(0, 1);
	for (int i = 0; i < m0; ++i)
		putchar(ans[i] + '0');
}