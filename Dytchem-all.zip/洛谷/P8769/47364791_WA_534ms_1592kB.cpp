#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef __int128 lll;
//#define int long long
#define Inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f

const int N = 100005;

int x,n;

struct P{
	int a,b,c;
	bool operator < (const P& p) const{
		if (a==p.a){
			if (b==p.b) return c<p.c;
			else return b<p.b;
		}
		else return a<p.a;
	}
}ps[N];

signed main(){
	cin>>x>>n;
	for (int i=1;i<=n;++i){
		cin>>ps[i].a>>ps[i].b>>ps[i].c;
	}
	
	sort(ps+1,ps+1+n);
	
	int ans=0,have=0;
	for (int i=1;i<=n&&have<x;++i){
		const P& p=ps[i];
		if (p.b>have){
			int can=min(p.c,p.b-have);
			if (have+can>=x){
				ans+=p.a*(x-have);
				have=x;
				break;
			}
			else{
				ans+=p.a*can;
				have+=can;
			}
		}
	}
	
	if (have==x) cout<<ans;
	else cout<<-1;
	
	return 0;
}