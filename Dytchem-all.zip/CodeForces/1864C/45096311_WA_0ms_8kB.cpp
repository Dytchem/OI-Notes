#include <bits/stdc++.h>
using namespace std;

template <typename T>
void read(T& a) {
	a = 0;
	bool f = false;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') f = true;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		a = (a << 1) + (a << 3) + c ^ 48;
		c = getchar();
	}
}


int main() {
	ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
	int t;
	cin >> t;
	while (t--) {
		int x;
		cin >> x;
		int k = 0;
		vector<int> ans{ x };
		while (ans.back() != 1) {
			const int now = ans.back();
			const int ma = ceil(sqrt(now));
			int i = 2;
			for (; i <= ma; ++i) {
				if (now % i == 0) {
					goto loop;
				}
			}
			if (false) {
			loop: ans.push_back(now - now / i);
			}
			else {
				ans.push_back(now - 1);
			}
		}
		cout << ans.size() << '\n';
		for (int a : ans) cout << a << ' ';
		cout << '\n';
	}
}