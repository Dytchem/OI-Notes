#include <bits/stdc++.h>
using namespace std;


int main() {
	ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
	int t;
	cin >> t;
	while (t--) {
		int n;
		cin >> n;
		vector<bool> b(n + 1);
		int cnt = 0;
		int x = 1;
		while (true) {
			++cnt;
			cout << x << ' ';
			b[x] = true;
			x <<= 1;
			if (x > n) {
				x = 1;
				while (x <= n && b[x]) ++x;
			}
			if (cnt == n) break;
		}
		cout << '\n';
	}
}