#define _CRT_SECURE_NO_WARNINGS
#include <bits/stdc++.h>
using namespace std;

template <typename T>
void read(T& a) {
	a = 0;
	bool f = false;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') f = true;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		a = (a << 1) + (a << 3) + c ^ 48;
		c = getchar();
	}
}

const int maxn = 200005;
int a[maxn];

int solve() {
	int n, k; cin >> n >> k;
	for (int i = 1; i <= n; ++i) cin >> a[i];

	if (k == 1) {
		for (int i = 1; i <= n; ++i) if (a[i] != i) return cout << "NO", 0;
		return cout << "YES", 0;
	}

	for (int i = 1; i <= n; ++i) {
		int j = i, cnt = 0;
		while (cnt <= k + 1) {
			j = a[j];
			++cnt;
			if (i == j) break;
		}
		if (cnt < k) return cout << "NO", 0;
		else if (cnt == k) return cout << "YES", 0;
	}
	return cout << "NO", 0;
}

int main() {
	ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
	int t; cin >> t;
	while (t--) {
		solve();
		cout << '\n';
	}
}