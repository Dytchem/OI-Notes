#include <bits/stdc++.h>
using namespace std;


int main() {
	ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
	int t;
	cin >> t;
	while (t--) {
		int m, k, a1, ak;
		cin >> m >> k >> a1 >> ak;
		const int ma = a1 + k * ak;
		if (ma == m) cout << 0;
		else if (ma > m) {
			if (a1 >= m) cout << 0;
			else {
				int y = (m - a1) / k;
				int x = m - k * y;
				cout << x - a1;
			}
		}
		else {
			int y = (m - a1 - 1) / k + 1;
			int x = m - k * y;
			if (x < 0) {
				y = (m - a1) / k;
				x = m - k * y;
			}
			if (x <= a1) cout << y - ak;
			else cout << x - a1 + y - ak;
		}
		cout << '\n';
	}
}