#include <bits/stdc++.h>
using namespace std;


int main() {
	ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
	int t;
	cin >> t;
	while (t--) {
		int m, k, a1, ak;
		cin >> m >> k >> a1 >> ak;
		int xm = m - k * ak;
		if (xm < 0) {
			int y = (m - a1 - 1) / k + 1;
			int x = m - k * y;
			if (x < 0) {
				int y = (m - a1) / k;
				int x = m - k * y;
				cout << x - a1;
			}
			else cout << 0;
		}
		else if (xm <= a1) {
			cout << 0;
		}
		else {
			int y = (m - a1) / k;
			int x = m - k * y;
			int ans = x - a1 + y - ak;
			y = (m - a1 - 1) / k + 1;
			x = m - k * y;
			if (x >= 0) ans = min(ans, y - ak);
			cout << ans;
		}
		cout << '\n';
	}
}