#include <bits/stdc++.h>
using namespace std;

template <typename T>
void read(T& a) {
	a = 0;
	bool f = false;
	char c = getchar();
	while (c < '0' || c > '9') {
		if (c == '-') f = true;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		a = (a << 1) + (a << 3) + c ^ 48;
		c = getchar();
	}
}

const int maxn = 3005;

int n;
char b[maxn][maxn];
bool laz[maxn][maxn];
int cnt1 = 0;

inline bool is1(const int x, const int y) {
	return b[x][y] ^ laz[x][y];
}

inline void change(const int x, const int y) {
	if (is1(x, y)) --cnt1;
	else ++cnt1;
	b[x][y] ^= 1;
}

void operate(const int x, const int y) { // x < n
	int y1 = y;
	if (laz[x][y]) {
		laz[x][y] ^= 1;
	}
	else {
		for (int i = x; i <= n && y1 >= 1; ++i) {
			if (laz[i][y1]) {
				if (is1(i, y1)) --cnt1;
				else ++cnt1;
				laz[i][y1] ^= 1;
				break;
			}
			change(i, y1);
			--y1;
		}
		y1 = y;
	}
	for (int i = x + 1; i <= n; ++i) {
		laz[i][y1] ^= 1;
		if (y1 < n) {
			++y1;
			laz[i][y1] ^= 1;
		}
	}
}

void update(const int x, const int y) {
	laz[x][y] ^= 1;
	int y1 = y;
	for (int i = x; i <= n && y1 >= 1; ++i) {
		if (laz[i][y1]) {
			if (is1(i, y1)) --cnt1;
			else ++cnt1;
			laz[i][y1] ^= 1;
			break;
		}
		change(i, y1);
		--y1;
	}
}


int main() {
	ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
	int t;
	cin >> t;
	while (t--) {
		cnt1 = 0;

		cin >> n;
		for (int i = 1; i <= n; ++i) for (int j = 1; j <= n; ++j) {
			cin >> b[i][j];
			b[i][j] -= '0';
			if (b[i][j]) ++cnt1;
			laz[i][j] = false;
		}

		if (cnt1 == 0) {
			cout << 0 << '\n';
			continue;
		}
		int ans = 0;
		for (int i = 1; i <= n - 1; ++i) for (int j = 1; j <= n; ++j) {
			if (is1(i, j)) operate(i, j), ++ans;
			else if (laz[i][j]) update(i, j);
		}
		for (int j = 1; j <= n; ++j) ans += is1(n, j);
		cout << ans << '\n';
	}
}

/*

1
10
1010110101
0101011011
1101001011
0110110111
1111111111
1111111111
0100000011
0111111111
1011111111
0011011101

ans: 46
*/