#include <bits/stdc++.h>
using namespace std;
constexpr int Inf = 0x7fffffff;


int main() {
	ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
	int t;
	cin >> t;
	while (t--) {
		int n;
		cin >> n;
		int mi1 = Inf, mi2 = Inf;
		bool flag = true;
		int ans = 0;
		while (n--) {
			int p;
			cin >> p;
			if (flag) {
				if (p < mi1) mi2 = mi1, mi1 = p, flag = false;
				else if (p < mi2) mi2 = p, ++ans;
			}
			else {
				if (p < mi1) mi2 = mi1, mi1 = p;
				else if (p < mi2) mi2 = p, ++ans, flag = true;
				else ++ans;
			}
		}
		cout << ans << '\n';
	}
}