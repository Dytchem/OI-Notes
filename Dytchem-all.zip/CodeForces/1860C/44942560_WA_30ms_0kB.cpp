#include <bits/stdc++.h>
using namespace std;
constexpr int Inf = 0x7fffffff;


int main() {
	ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
	int t;
	cin >> t;
	while (t--) {
		int n;
		cin >> n;
		int mi1 = Inf, mi2 = Inf;
		int ans = 0;
		while (n--) {
			int p;
			cin >> p;
			if (p > mi2) ++ans;
			else if (p < mi1) mi2 = mi1, mi1 = p;
			else mi2 = p;
		}
		cout << ans << '\n';
	}
}