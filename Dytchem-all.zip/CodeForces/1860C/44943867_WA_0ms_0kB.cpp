#include <bits/stdc++.h>
using namespace std;
constexpr int Inf = 0x7fffffff;


int main() {
	ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
	int t;
	cin >> t;
	while (t--) {
		int n;
		cin >> n;
		int m1 = Inf, m2 = Inf, tmp = Inf;
		cin >> m1;
		int ans = 0;
		while (--n) {
			int p;
			cin >> p;
			if (p < m1) {
				if (p < tmp) tmp = p;
				else m1 = tmp, m2 = p;
			}
			else if (p < m2) m2 = p, ++ans;
		}
		cout << ans << '\n';
	}
}