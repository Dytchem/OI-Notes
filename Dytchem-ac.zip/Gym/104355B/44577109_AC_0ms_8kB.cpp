#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
constexpr int INF = 0x7fffffff;

int main() {
	ios::sync_with_stdio(false);
	double a, b;
	cin >> a >> b;
	cout << setprecision(10) << a / b;
}