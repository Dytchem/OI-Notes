#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
constexpr int INF = 0x7fffffff;

int main() {
	int x, y, z;
	cin >> x >> y >> z;
	printf("%.6f", (double)z / (x * y));
}