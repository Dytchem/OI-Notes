#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
constexpr int INF = 0x7fffffff;

int main() {
	ios::sync_with_stdio(false);
	int n;
	cin >> n;
	if (n <= 6) cout << "water";
	else cout << "dry";
	return 0;
}